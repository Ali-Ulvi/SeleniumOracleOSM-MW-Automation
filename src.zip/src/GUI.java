import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {
      setImage setIcon = new setImage();
    GUI() {
        super("AUToOSM");
        setIcon.setIcon(this);
        JTabbedPane jTabbedPane = new JTabbedPane();
        JCheckBox checkBoxResolve = new JCheckBox("Resolve Order Failure");
        checkBoxResolve.setSelected(true);
        JPanel osm = new JPanel();
        JPanel orderPanel = new JPanel();
        JLabel osmidLabel = new JLabel("OSM Order ID: ");
        JTextField osmidTextField = new JTextField();
        osmidTextField.setColumns(9);
        orderPanel.add(osmidLabel);
        orderPanel.add(osmidTextField);
        orderPanel.add(checkBoxResolve);
        JPanel buttonsPanel = new JPanel();
        RoundButton fBtn = new RoundButton(new ImageIcon(getClass().getResource("f.png")));
        fBtn.setHorizontalAlignment(SwingConstants.CENTER);

        RoundButton rBtn = new RoundButton(new ImageIcon(getClass().getResource("r.png")));
        rBtn.setSize(fBtn.getSize());
        rBtn.setHorizontalAlignment(SwingConstants.CENTER);
        rBtn.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

        //fBtn.setMargin(new Insets(fBtn.getMargin().top, fBtn.getMargin().left, fBtn.getMargin().bottom, fBtn.getMargin().right * 5));
        buttonsPanel.add(fBtn);
        buttonsPanel.add(new Label("    "));
        buttonsPanel.add(rBtn);

        osm.setLayout(new BoxLayout(osm, BoxLayout.Y_AXIS));
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        osm.add(orderPanel);
        osm.add(buttonsPanel);
        JButton viewOrderStatus = new JButton("View Order Status");
        osm.add(viewOrderStatus);
        viewOrderStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
        jTabbedPane.add("OSM", osm);
        add(jTabbedPane);
        osmidTextField.setForeground(Color.BLACK);
        CutCopyPastActionSupport support = new CutCopyPastActionSupport();
        support.setPopup(osmidTextField);

        JMenu ab = new JMenu("About");

        JMenuItem jMenuThx = new JMenuItem(new AbstractAction("THANKS") {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[] options = {"  THANKS!  "};

                if (JOptionPane.showOptionDialog(GUI.this, "" +
                                "                                DEVELOPED BY:\n                                --------------------------\n                                ALİ ULVİ TALİPOGLU\n\n\n" +
                                "                                Special Thanks for Button Designs:\n                                ----------------------------------------\n                                Erdal YILMAZ\n\n"
                        , "About & Credits",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                        null, options, null) == 0) {
                    setTitle(getTitle() + " \u2661");
                    repaint();
                }
                // JOptionPane.showInternalMessageDialog(f,"      THANKS\n\nALİ ULVİ TALİPOGLU","Credits",JOptionPane.INFORMATION_MESSAGE);

            }
        });
        ab.add(jMenuThx);
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(support.getMenu());
        menuBar.add(ab);
        setJMenuBar(menuBar);

        fBtn.setRolloverIcon(new ImageIcon(getClass().getResource("fR.png")));
        fBtn.setPressedIcon(new ImageIcon(getClass().getResource("fPr.png")));
        rBtn.setPressedIcon(new ImageIcon(getClass().getResource("rpr.png")));
        rBtn.setRolloverIcon(new ImageIcon(getClass().getResource("rR.png")));
        rBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (osmidTextField.getText().isEmpty()) {
                    osmidTextField.setBackground(Color.PINK);
                    osmidTextField.setForeground(Color.WHITE);
                    return;
                }
                osmidTextField.setBackground(Color.WHITE);
                osmidTextField.setForeground(Color.BLUE);
                setIcon.setResubmit(GUI.this);
                new Move(osmidTextField.getText(), checkBoxResolve.isSelected(), false);
            }
        });
        fBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (osmidTextField.getText().isEmpty()) {
                    osmidTextField.setBackground(Color.RED);
                    osmidTextField.setForeground(Color.WHITE);

                    return;
                }
                osmidTextField.setBackground(Color.WHITE);
                osmidTextField.setForeground(Color.BLACK);
                setIcon.setForce(GUI.this);
                new Move(osmidTextField.getText(), checkBoxResolve.isSelected(), true);
            }
        });
        viewOrderStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (osmidTextField.getText().isEmpty()) {
                    osmidTextField.setBackground(Color.RED);
                    osmidTextField.setForeground(Color.WHITE);

                    return;
                }
                osmidTextField.setBackground(Color.WHITE);
                osmidTextField.setForeground(Color.BLACK);

                new Move(osmidTextField.getText(), null, false);
            }
        });

        setVisible(true);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    static class setImage {
        void setIcon(JFrame frame) {
            String img = "";
            if (this.hashCode() % 2 == 0)
                img = "f.png";
            else
                img = "r.png";
            frame.setIconImage(new ImageIcon(getClass().getClassLoader().getResource(img)).getImage());
        }

        void setForce(JFrame frame) {
            String img = "f.png";
            frame.setIconImage(new ImageIcon(getClass().getClassLoader().getResource(img)).getImage());
        }
        void setResubmit(JFrame frame) {
            String img = "r.png";
            frame.setIconImage(new ImageIcon(getClass().getClassLoader().getResource(img)).getImage());
        }
    }
}
