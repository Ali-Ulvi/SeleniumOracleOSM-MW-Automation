package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import static POM.ChangeState.waitt;

public class Search {
    private WebDriver driver;
    String osmID;
    @FindBy(css = "#pt1\\:r1\\:0\\:orderQueryId\\:value00\\:\\:content")
    private WebElement orderID;
    @FindBy(css = "#pt1\\:r1\\:1\\:actionsMenu > div > table > tbody > tr > td.x112 > a")
    private WebElement actionsButton;
    @FindBy(css = "#pt1\\:r1\\:0\\:orderQueryId\\:\\:search")
    private WebElement search;
    @FindBy(xpath = "//td[text()='Resolve Order Failure']")
    private WebElement resolveOrderFailureCommandMenuItem;
    @FindBy(css = "#pt1\\:r1\\:oaprrit1")
    private WebElement reasonText;
    @FindBy(css = "#pt1\\:r1\\:0\\:pc1\\:resultsTable\\:\\:db > table > tbody > tr > td:nth-child(1) > span > span")
    private WebElement searchResult;
    @FindBy(css = "#pt1\\:r1\\:1\\:resolveOrderDialog\\:\\:ok")
    private WebElement reasonOkButton;
    WebDriverWait wait;

    //Constructor
    public Search(WebDriver driver, String osmID) {
        this.driver = driver;
        this.osmID = osmID;
        //Initialise Elements
        PageFactory.initElements(driver, this);
        go();
        wait = new WebDriverWait(driver, 90);
        wait.until(ExpectedConditions.textToBePresentInElement(searchResult, "3258446"));

    }

    void go() {
        driver.get("http://172.31.70.234:7004/OrderManagement/orchestration/faces/home?_afrLoop=1649388252912588&_afrWindowMode=0&_adf.ctrl-state=1efbu0bn5_14");
        Login login = new Login(driver);
        if (login.isPageOpened()) {
            login.setUname("osmAdmin");
            login.setPwAndEnter("osmAdmin123!");
        }

    }

    public Search search() {
        orderID.clear();
        orderID.sendKeys(osmID);
        search.click();


        wait.until(ExpectedConditions.textToBePresentInElement(searchResult, osmID));
        Actions actions = new Actions(driver);
        actions.doubleClick(searchResult).perform();

        return this;
    }

    public Search resolveFailure() {
        wait.until(ExpectedConditions.textToBePresentInElement(actionsButton, "Actions"));
        actionsButton.click();
        waitt(1);
        resolveOrderFailureCommandMenuItem.click();
        wait.until(ExpectedConditions.textToBePresentInElement(reasonOkButton, "OK"));
        waitt(2);
        reasonText.sendKeys("manual");
        reasonOkButton.click();
        return this;
    }


}