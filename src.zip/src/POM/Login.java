package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
    private WebDriver driver;

    @FindBy(css = "#LoginFields > input.UserNameComponent")
    private WebElement uname;
    @FindBy(css = "#LoginFields > input.PasswordComponent")
    private WebElement pw;
    @FindBy(css = "#LoginButtons > input.LoginText")
    private WebElement login;

    //Constructor
    public Login(WebDriver driver){
        this.driver=driver;

        //Initialise Elements
        PageFactory.initElements(driver, this);
    }
    //We will use this boolean for assertion. To check if page is opened
    public boolean isPageOpened(){
        return driver.getTitle().contains("Login - ");
    }

    public void setUname(String user){
        uname.sendKeys(user);
    }
    public void setPwAndEnter(String pass){
        pw.sendKeys(pass);
        login.click();
    }
}