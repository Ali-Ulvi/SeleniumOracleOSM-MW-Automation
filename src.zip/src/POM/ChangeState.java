package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ChangeState {
    private WebDriver driver;

    @FindBy(css = "input#assigned")
    private WebElement assignRadio;

    @FindBy(css = "input#completed")
    private WebElement completedRadio;

    @FindBy(css = "input#accepted")
    private WebElement acceptRadio;

    @FindBy(css = "table.buttonBar input[value='Update']")
    private WebElement updateButton;

    @FindBy(css = "#assigned > select")
    private WebElement selectAssignee;
    Select selectAssigneeBox;

    @FindBy(css = "select[name=StatusID]")
    private WebElement selectStatus;
    Select selectStatusBox;

    //Constructor
    public ChangeState(WebDriver driver) {
        this.driver = driver;
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    public static void waitt(long saniye) {
        try {
            Thread.sleep(saniye * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void assign() {

        assignRadio.click();
        selectAssigneeBox = new Select(selectAssignee);
        selectAssigneeBox.selectByValue("osmadmin");
        updateButton.click();

    }

    public void accept() {
        acceptRadio.click();
        updateButton.click();

    }

    public void completed() {

        completedRadio.click();
        selectStatusBox = new Select(selectStatus);
        try {
            selectStatusBox.selectByValue("10107");
        } catch (Exception e) {
            System.out.println(e.getMessage());

            selectStatusBox.selectByValue("10114");
        }
        updateButton.click();

    }

    public void forceCompleted() {

        completedRadio.click();
        selectStatusBox = new Select(selectStatus);
        try {
            selectStatusBox.selectByValue("10113");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            selectStatusBox.selectByValue("10114");
        }
        updateButton.click();

    }

    public void reSubmitCompleted() {

        completedRadio.click();
        selectStatusBox = new Select(selectStatus);

        selectStatusBox.selectByValue("10109");
        updateButton.click();

    }

}