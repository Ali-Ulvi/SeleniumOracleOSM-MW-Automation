package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static POM.ChangeState.waitt;

public class Worklist {
    private WebDriver driver;
    String osmID;
    @FindBy(name = "orderIDFilter")
    private WebElement orderID;
    @FindBy(css = "input[value='changeState']")
    private WebElement changeState;
    @FindBy(css = "#BodyIndex > form > table.buttonBar > tbody > tr > td > p > input.button")
    private WebElement refresh;
    //@FindBy(css = "input[name=move]")
    private WebElement move;
    @FindBy(css = "tr.context-menu-target > td:nth-of-type(8)")
    private WebElement processTd;
    String process=null;


    //Constructor
    public Worklist(WebDriver driver, String osmID) {
        this.driver = driver;
        this.osmID = osmID;
        //Initialise Elements
        PageFactory.initElements(driver, this);
        go();
    }

    public Worklist go() {
        driver.get("http://172.31.70.234:7004/OrderManagement/control/worklist.do?orderIDFilter=3164640&pageAction=refresh".replace("3164640", osmID));
        Login login = new Login(driver);
        if (login.isPageOpened()) {
            login.setUname("osmAdmin");
            login.setPwAndEnter("osmAdmin123!");
        }
        return this;

    }

    public Worklist clickChangeStateRadio() {
        changeState.click();
        return this;
    }

    public Worklist refresh() {
        refresh.click();

        try {
            while (!orderID.getCssValue("background-color").equals("rgba(255, 255, 255, 1)"))
                Thread.sleep(1111);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return this;
    }

    public ChangeState move() {
        if (process==null)
            process=processTd.getText();
        move=driver.findElement(By.xpath("//tr[@class=\"context-menu-target\" and (td[position()=8 and contains(text(),'"+process+"') ])]/td/input"));
        System.out.println("//tr[@class=\"context-menu-target\" and (td[position()=8 and contains(text(),'"+process+"') ])]/td/input");
        move.click();

        return new ChangeState(driver);
    }


}