
import PMPOM.Login;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ShowPM {

    ShowPM(String pid) {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        Login login = new Login(driver);
        login.setUname("admin");
        login.setPwAndEnter("admin");

    }
}
