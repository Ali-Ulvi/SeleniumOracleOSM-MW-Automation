import POM.ChangeState;
import POM.Login;
import POM.Search;
import POM.Worklist;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;

public class Main {
static  ChangeState move(Worklist worklist ){
    return worklist.go().clickChangeStateRadio().refresh().move();
}
    public static void main(String[] args) {

        new GUI();
        Runtime.getRuntime().addShutdownHook(new Thread()
        {
            public void run()
            {
                System.out.println("taskkill /F /IM chromedriver.exe");
                try {
                    Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

/*
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        WebDriver driver = new ChromeDriver();driver.manage().window().maximize();
        //Worklist worklist = new Worklist(driver,"3164640");
        Login login = new Login(driver);
        if (login.isPageOpened()){
            login.setUname("osmAdmin");
            login.setPwAndEnter("osmAdmin123!");
        }

        Search search=new Search(driver,"3164640");
        search.search().resolveFailure();
        System.exit(2);
        Worklist worklist = new Worklist(driver,"3258977");

        ChangeState changeStatePage = worklist.clickChangeStateRadio().refresh().move();
        changeStatePage.assign();
        move(worklist).accept();
        move(worklist).completed();
        move(worklist).accept();
        //move(worklist).forceCompleted();//or
        move(worklist).reSubmitCompleted();
*/

    }
}
