import POM.ChangeState;
import POM.Login;
import POM.Search;
import POM.Worklist;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Move {
    static ChangeState move(Worklist worklist) {
        return worklist.go().clickChangeStateRadio().refresh().move();
    }

    Boolean failureResolved = false;

    Move(String osmID, Boolean resolveFailure, boolean force) {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        //Worklist worklist = new Worklist(driver,"3164640");
        Login login = new Login(driver);
        if (login.isPageOpened()) {
            login.setUname("osmAdmin");
            login.setPwAndEnter("osmAdmin123!");
        }
        if (resolveFailure!=null&&resolveFailure) {
            try {
                Search search = new Search(driver, osmID);
                search.search().resolveFailure();
                failureResolved = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }//resolve failure yapınca support cikmior direk force yap. opensa direk force yapabilirsin yine. opensa resubmit yapacaksan support seç.
        Worklist worklist = new Worklist(driver, osmID);
        if(failureResolved==null)
            return;
        ChangeState changeStatePage = worklist.clickChangeStateRadio().refresh().move();
        changeStatePage.assign();
        move(worklist).accept();
        if (!failureResolved) {
            move(worklist).completed();
            move(worklist).accept();
        }
        if (force)
            move(worklist).forceCompleted();//or
        else
            move(worklist).reSubmitCompleted();
    }
}
