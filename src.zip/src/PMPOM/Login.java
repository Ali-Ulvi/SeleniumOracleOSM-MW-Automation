package PMPOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
    private WebDriver driver;

    @FindBy(css = "#j_username")
    private WebElement uname;
    @FindBy(css = "#j_password")
    private WebElement pw;
    @FindBy(css = "#loginButton")
    private WebElement login;

    //Constructor
    public Login(WebDriver driver){
        this.driver=driver;
driver.get("http://172.31.70.230:9090/om-gui/modules/common/login.jsf");
        //Initialise Elements
        PageFactory.initElements(driver, this);

    }
    //We will use this boolean for assertion. To check if page is opened
    public boolean isPageOpened(){
        return driver.getTitle().contains("Login");
    }

    public void setUname(String user){
        uname.sendKeys(user);
    }
    public void setPwAndEnter(String pass){
        pw.sendKeys(pass);
        login.click();
    }
}